%%Crop the 600ms window after stimulation
clear all
myFolder = uigetdir();
EEGname = ['*.mat']; 
EEGdir = fullfile(myFolder, EEGname);
EEGfiles = dir(EEGdir);
alldata = null;


for m = 1:length(EEGfiles)
load(EEGfiles(m).name); 
alldata = alldata + newData; 
% %%filter 
% w1=[59/256,61/256]; %60Hz stop band 
% w2=[60/256]; 
% w3=[5/256];
% [b,a]=butter(4,w1,'stop');
% [d,c]=butter(4,w2,'low');
% [e,f]=butter(4,w3,'high');
% filt1=filtfilt(b,a,data(:,1));
% filt2=filtfilt(d,c,filt1);
% filt3=filtfilt(e,f,filt2);
% % timestamp = (1:(512*6))/512 - 2;
% % plot(timestamp,data);
% 
% newData = filt3(1024:(1024+308));
%newname = strcat('Bandpass5_60hz_',EEGfiles(m).name);

end
alldata = alldata/length(EEGfiles);
save (newname,'alldata');

